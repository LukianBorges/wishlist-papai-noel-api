const express = require('express');
const app = express();

app.use(express.json());

let desejos = [];

app.get('/health', (req, res) => {
  res.json({ status: 'Wish Service OK' });
});

app.get('/desejos', (req, res) => {
  res.json(desejos);
});

app.post('/desejos', (req, res) => {
  const desejo = req.body;
  desejos.push(desejo);
  res.status(201).json(desejo);
});

app.listen(3000, '0.0.0.0', () => {
  console.log('Wish Service rodando na porta 3000');
});
